# Consensus Trace

**LIVE RPC OBSERVATION — READ-ONLY**

Case: Grounding verifier · current finalized verdict
Report: e6cdac42-824d-43b1-bdba-2553ef050610
Captured: 2026-10-08T21:23:15.372Z
Conclusion: CHECKS_PASSED

Network: bradbury; configured chain ID 4221; chain verified: true

Contract: https://explorer-bradbury.genlayer.com/address/0xb08773A551302B816F6bF3cce914D266b5C1a461
Transaction: https://explorer-bradbury.genlayer.com/tx/0x7e72eb0d3673b4e7fde739437c21931009751dc9b3129b3921285b5ad8ed00ba
Pinned source: https://github.com/Leokings/agent-output-grounding-verifier/blob/b95bc1f8a7c41a2c880b7da8fbeef2247cd1a99f/contracts/AgentOutputGroundingVerifier.py

## Verified layers

- Receipt binding: transaction=true; recipient=true
- Stored lifecycle: FINALIZED; finalized=true
- Execution: SUCCESS (receipt.txExecutionResult)
- Source comparison: EXACT
- Assertions: 1/1 passed against current latest-final state

## Findings

## Assertion results

- Stored verdict for verification 1: PASS — Expected assertion matches the current latest-final read.

## Limitations

- This is read-only verification of an existing transaction. No deployment, write, appeal or finalize command is sent.
- latest-final reads observe current finalized state, not historical state at this transaction. A passing assertion does not prove this transaction caused the observed value.
- Source comparisons observe currently deployed code; transaction-time code provenance is not independently proven.
- RPC observations and hashes are evidence and integrity checks, not independent cryptographic proof of chain truth.
- Missing provider logs cannot establish that prompt complexity or a particular model caused a timeout.
- Frontend staleness is not diagnosed without an instrumented, equivalent frontend read. An unavailable state read is not a stale UI.
- A debug trace may be replay-reconstructed; this adapter cannot independently distinguish an original trace from a replay.
- Hosted history is browser-local and may be cleared by browser settings. The hosted API does not store or share a history of your reports.
- Public-site request/concurrency limits are per function instance, not a globally distributed rate limit. Replay-capable traces and localnet are disabled.

## Integrity and redaction

Best-effort credential-field and token-pattern redaction. Review before sharing. Original source digests were calculated before redaction; manifest hashes cover the exported, redacted bytes.

Verify file hashes against manifest.json. A self-contained manifest is not a signature or proof of authenticity. Preserve the ZIP SHA-256 separately if you need a trusted integrity anchor.
