# Consensus Trace

**LIVE RPC OBSERVATION — READ-ONLY**

Case: Grounding verifier — historical smoke receipt, current finalized state
Report: 39836a19-9578-4075-bb23-e2d995e89e9d
Captured: 2026-10-08T22:38:27.526Z
Conclusion: CHECKS_PASSED

Network: bradbury; configured chain ID 4221; chain verified: true

Contract: https://explorer-bradbury.genlayer.com/address/0xb08773A551302B816F6bF3cce914D266b5C1a461
Transaction: https://explorer-bradbury.genlayer.com/tx/0x7e72eb0d3673b4e7fde739437c21931009751dc9b3129b3921285b5ad8ed00ba
Pinned source: https://github.com/Leokings/agent-output-grounding-verifier/blob/b95bc1f8a7c41a2c880b7da8fbeef2247cd1a99f/contracts/AgentOutputGroundingVerifier.py

## Verified layers

- Receipt binding: transaction=true; recipient=true
- Stored lifecycle: FINALIZED; finalized=true
- Execution: SUCCESS (receipt.txExecutionResult)
- Source comparison: EXACT
- Assertions: 1/1 passed against current latest-final state

## Findings

## Assertion results

- Stored verdict for verification 1: PASS — Expected assertion matches the current latest-final read.

## Limitations

- This is read-only verification of an existing transaction. No deployment, write, appeal or finalize command is sent.
- latest-final reads observe current finalized state, not historical state at this transaction. A passing assertion does not prove this transaction caused the observed value.
- Source comparisons observe currently deployed code; transaction-time code provenance is not independently proven.
- RPC observations and hashes are evidence and integrity checks, not independent cryptographic proof of chain truth.
- Missing provider logs cannot establish that prompt complexity or a particular model caused a timeout.
- Frontend comparisons use supplied captures of equivalent reads. They do not authenticate a third-party UI. Missing reads, old captures and different read identities are not stale-UI proof.
- A debug trace may be replay-reconstructed; this adapter cannot independently distinguish an original trace from a replay.

## Integrity and redaction

Best-effort credential-field and token-pattern redaction. Review before sharing. Original source digests were calculated before redaction; manifest hashes cover the exported, redacted bytes.

Verify file hashes against manifest.json. A self-contained manifest is not a signature or proof of authenticity. Preserve the ZIP SHA-256 separately if you need a trusted integrity anchor.
