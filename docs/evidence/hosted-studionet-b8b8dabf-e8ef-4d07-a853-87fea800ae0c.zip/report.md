# Consensus Trace

**LIVE RPC OBSERVATION — READ-ONLY**

Case: StudioNet · receipt-only check
Report: b8b8dabf-e8ef-4d07-a853-87fea800ae0c
Captured: 2026-10-08T20:33:10.868Z
Conclusion: INCOMPLETE

Network: studionet; configured chain ID 61999; chain verified: true

Contract: https://explorer-studio.genlayer.com/address/0x62122cb6486bc664084dec8c93ec6a61f1c51016
Transaction: https://explorer-studio.genlayer.com/tx/0x786d6828903e6b37e82d94e7b7ea94575369d8d34d7008b837157581658f5059

## Verified layers

- Receipt binding: transaction=true; recipient=true
- Stored lifecycle: FINALIZED; finalized=true
- Execution: SUCCESS (receipt.consensus_data.leader_receipt[mode=leader].execution_result)
- Source comparison: NOT_REQUESTED
- Assertions: 0/0 passed against current latest-final state

## Findings

### WARNING: Source provenance is incomplete

Code: SOURCE_UNVERIFIED; classification: observed

No commit-pinned public source was provided.

Evidence: source, observations.deployedCode, observations.pinnedSource
Next check: Provide a public repository, full commit SHA and exact file path.

### WARNING: Finalized success, but schema read unavailable

Code: SCHEMA_UNAVAILABLE; classification: observed

The schema endpoint failed after a successfully executed finalized receipt. This is a read/schema availability issue, not proof of stale frontend state.

Evidence: observations.schema, receipt
Next check: Refresh the read endpoint and compare the explorer; preserve the successful receipt.

### INFO: No application-result assertions supplied

Code: NO_ASSERTIONS; classification: limitation

Execution success alone does not verify the intended application result.

Evidence: input.assertions
Next check: Add a latest-final view assertion with a case/request identifier.

## Assertion results


## Limitations

- This is read-only verification of an existing transaction. No deployment, write, appeal or finalize command is sent.
- latest-final reads observe current finalized state, not historical state at this transaction. A passing assertion does not prove this transaction caused the observed value.
- Source comparisons observe currently deployed code; transaction-time code provenance is not independently proven.
- RPC observations and hashes are evidence and integrity checks, not independent cryptographic proof of chain truth.
- Missing provider logs cannot establish that prompt complexity or a particular model caused a timeout.
- Frontend staleness is not diagnosed without an instrumented, equivalent frontend read. An unavailable state read is not a stale UI.
- A debug trace may be replay-reconstructed; this adapter cannot independently distinguish an original trace from a replay.
- Hosted history is browser-local and may be cleared by browser settings. The hosted API does not store or share a history of your reports.
- Public-site request/concurrency limits are per function instance, not a globally distributed rate limit. Replay-capable traces and localnet are disabled.

## Integrity and redaction

Best-effort credential-field and token-pattern redaction. Review before sharing. Original source digests were calculated before redaction; manifest hashes cover the exported, redacted bytes.

Verify file hashes against manifest.json. A self-contained manifest is not a signature or proof of authenticity. Preserve the ZIP SHA-256 separately if you need a trusted integrity anchor.
